const sub2 = this.angularFirestore.collection('TimeCards').doc(this.prevUsername).collection(this.datePart).snapshotChanges();
// below method will retrieve URL after passing;
const getImageURL = storageRef =>
  new Promise(resolve => {
      storageRef.getDownloadURL().then(url => {
          resolve(url);
        }, err => {
        }
      );
    }
  );
let sub2gCopy;
const sub2gArray = [];
let acount = 0;

// subscriber 
const sub2g = await sub2.subscribe((snapData1: DocumentChangeAction<any>[]) => {
  acount++;
 console.log('**************', acount);
 if (sub2gArray.length){
   sub2gArray.forEach(suscriberr => {
     suscriberr.unsubscribe();
   });
 }
 sub2gArray.push(sub2g);
 if (sub2gCopy){
   sub2gCopy.unsubscribe();
   this.timestampsList1 = [];
 }
 sub2gCopy = sub2g;
  const setArray = async () => {
  this.timestampsList1 = [];
  let scount = 0;
  for (const d of snapData1) {
    scount++;
    console.log('sc', scount);
    if (d.payload.doc.data().screenShot) {
          const storageRef = firebase.storage().ref().child(d.payload.doc.data().screenShot);
          const ImgUrl = await getImageURL(storageRef);
          this.timestampsList1.push({
              dateObj: d.payload.doc.data().dateObj,
              imageUrl: ImgUrl,
              date: d.payload.doc.data().screenShot,
              name: d.payload.doc.data().user
            });
    }
  }
  console.log('whole array ', this.timestampsList1);
};
this.timestampsList1 = [];
setArray();
});
